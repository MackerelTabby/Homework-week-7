import org.junit.Test;

import static org.junit.Assert.*;

public class SequenceSearchImplTest {
    @Test
    public void getAllTaggedSequences() throws Exception {
    }

    @Test
    public void getLongestTaggedSequence() throws Exception {
    }

    @Test
    public void displayStringArray() throws Exception {
    }

    @Test
    public void occurrences() throws Exception {
    }

    @Test
    public void append() throws Exception {
    }

//    @Test
  //  public void toString() throws Exception {
   // }

}